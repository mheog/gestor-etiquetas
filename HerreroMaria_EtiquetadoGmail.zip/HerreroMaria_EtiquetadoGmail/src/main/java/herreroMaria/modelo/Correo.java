package herreroMaria.modelo;

public class Correo {

    private final String asunto;

    public Correo(String asunto) {
        this.asunto = asunto;
    }

    public String getAsunto() {
        return asunto;
    }

}